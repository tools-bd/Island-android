package com.island.app

import android.app.Activity
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.widget.*

class MainActivity : Activity() {

    private lateinit var status: TextView
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val sp = Prefs.sp(this)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(48), dp(20), dp(32))
        }
        col.addView(TextView(this).apply { text = "Island"; textSize = 32f; typeface = Typeface.DEFAULT_BOLD })
        status = TextView(this).apply { textSize = 15f; setPadding(0, dp(8), 0, dp(8)) }
        col.addView(status)
        col.addView(Button(this).apply {
            text = "Enable Island (Accessibility)"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        col.addView(TextView(this).apply {
            text = "Android 13+: if it's greyed out, go to App info > ⋮ > Allow restricted settings, then try again."
            textSize = 12f
        })

        slider(col, "Width (dp)", Prefs.W, 60, 260, 120)
        slider(col, "Height (dp)", Prefs.H, 20, 80, 34)
        slider(col, "Up / Down (dp)", Prefs.Y, 0, 120, 10)
        slider(col, "Left / Right (dp)", Prefs.X, -150, 150, 0)
        slider(col, "Corner radius (dp)", Prefs.R, 0, 40, 17)

        col.addView(TextView(this).apply { text = "Color"; textSize = 16f; setPadding(0, dp(16), 0, 0) })
        val row = LinearLayout(this)
        listOf(
            "Black" to 0xFF000000.toInt(), "Graphite" to 0xFF2C2C2E.toInt(),
            "Navy" to 0xFF0A2540.toInt(), "Red" to 0xFFB00020.toInt(), "White" to 0xFFFFFFFF.toInt()
        ).forEach { (n, c) ->
            row.addView(Button(this).apply {
                text = n; textSize = 10f
                setOnClickListener { sp.edit().putInt(Prefs.COLOR, c).apply() }
            }, LinearLayout.LayoutParams(0, -2, 1f))
        }
        col.addView(row)

        col.addView(Switch(this).apply {
            text = "Expand on notifications"
            isChecked = sp.getBoolean(Prefs.PEEK, true)
            setPadding(0, dp(16), 0, dp(8))
            setOnCheckedChangeListener { _, v -> sp.edit().putBoolean(Prefs.PEEK, v).apply() }
        })
        col.addView(Button(this).apply {
            text = "Test expand"
            setOnClickListener { sp.edit().putLong(Prefs.TEST, System.currentTimeMillis()).apply() }
        })

        setContentView(ScrollView(this).apply { addView(col) })
    }

    private fun slider(parent: LinearLayout, title: String, key: String, min: Int, max: Int, def: Int) {
        val sp = Prefs.sp(this)
        val cur = sp.getInt(key, def)
        val tv = TextView(this).apply { text = "$title: $cur"; textSize = 16f; setPadding(0, dp(16), 0, 0) }
        val sb = SeekBar(this).apply { this.max = max - min; progress = cur - min }
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                val v = p + min
                tv.text = "$title: $v"
                if (fromUser) sp.edit().putInt(key, v).apply()
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        parent.addView(tv); parent.addView(sb)
    }

    override fun onResume() {
        super.onResume()
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
        status.text = if (s.contains("$packageName/")) "Status: ON ✅" else "Status: OFF ❌ (enable it below)"
    }
}
