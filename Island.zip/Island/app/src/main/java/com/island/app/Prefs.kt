package com.island.app

import android.content.Context

object Prefs {
    const val W = "w"; const val H = "h"; const val X = "x"; const val Y = "y"
    const val R = "r"; const val COLOR = "color"; const val PEEK = "peek"; const val TEST = "test"
    fun sp(c: Context) = c.getSharedPreferences("island", Context.MODE_PRIVATE)
}
