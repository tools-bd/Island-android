package com.island.app

import android.accessibilityservice.AccessibilityService
import android.animation.ValueAnimator
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class IslandService : AccessibilityService(), SharedPreferences.OnSharedPreferenceChangeListener {

    private lateinit var wm: WindowManager
    private lateinit var island: FrameLayout
    private lateinit var label: TextView
    private lateinit var lp: WindowManager.LayoutParams
    private val bg = GradientDrawable()
    private val handler = Handler(Looper.getMainLooper())
    private val collapse = Runnable { setExpanded(false) }
    private var expanded = false
    private var added = false

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun clock() = SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date())

    override fun onServiceConnected() {
        super.onServiceConnected()
        if (added) return
        wm = getSystemService(WINDOW_SERVICE) as WindowManager

        label = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            maxLines = 2
            setPadding(dp(14), 0, dp(14), 0)
            visibility = View.GONE
        }
        island = FrameLayout(this).apply {
            background = bg
            addView(label, FrameLayout.LayoutParams(-1, -1))
            setOnClickListener { setExpanded(!expanded, clock()) }
        }
        val flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        lp = WindowManager.LayoutParams(
            dp(120), dp(34),
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            flags, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL }

        applyPrefs()
        wm.addView(island, lp)
        added = true
        Prefs.sp(this).registerOnSharedPreferenceChangeListener(this)
    }

    private fun applyPrefs() {
        val sp = Prefs.sp(this)
        lp.width = dp(sp.getInt(Prefs.W, 120))
        lp.height = dp(sp.getInt(Prefs.H, 34))
        lp.x = dp(sp.getInt(Prefs.X, 0))
        lp.y = dp(sp.getInt(Prefs.Y, 10))
        bg.setColor(sp.getInt(Prefs.COLOR, Color.BLACK))
        bg.cornerRadius = dp(sp.getInt(Prefs.R, 17)).toFloat()
        if (added) wm.updateViewLayout(island, lp)
    }

    private fun setExpanded(on: Boolean, text: String? = null) {
        handler.removeCallbacks(collapse)
        val sp = Prefs.sp(this)
        val baseW = dp(sp.getInt(Prefs.W, 120))
        val baseH = dp(sp.getInt(Prefs.H, 34)).coerceAtLeast(1)
        val baseR = dp(sp.getInt(Prefs.R, 17)).toFloat()
        val maxW = resources.displayMetrics.widthPixels - dp(24)
        val toW = if (on) minOf((baseW * 2.6f).toInt(), maxW) else baseW
        val toH = if (on) (baseH * 1.9f).toInt() else baseH
        val fromW = lp.width
        val fromH = lp.height
        expanded = on

        label.animate().cancel()
        if (on) {
            label.text = text ?: clock()
            label.alpha = 0f
            label.visibility = View.VISIBLE
            label.animate().alpha(1f).setStartDelay(120).setDuration(200).start()
        } else {
            label.visibility = View.GONE
        }

        ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 380
            interpolator = OvershootInterpolator(1.0f)
            addUpdateListener {
                val f = it.animatedValue as Float
                lp.width = (fromW + (toW - fromW) * f).toInt().coerceAtLeast(1)
                lp.height = (fromH + (toH - fromH) * f).toInt().coerceAtLeast(1)
                bg.cornerRadius = baseR * lp.height / baseH
                if (added) wm.updateViewLayout(island, lp)
            }
            start()
        }
        if (on) handler.postDelayed(collapse, 4000)
    }

    override fun onSharedPreferenceChanged(sp: SharedPreferences?, key: String?) {
        if (key == Prefs.TEST) { setExpanded(true, "Hello from Island"); return }
        handler.removeCallbacks(collapse)
        expanded = false
        label.visibility = View.GONE
        applyPrefs()
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (e == null || e.eventType != AccessibilityEvent.TYPE_NOTIFICATION_STATE_CHANGED) return
        if (!Prefs.sp(this).getBoolean(Prefs.PEEK, true)) return
        if (e.packageName == packageName) return
        val txt = e.text.joinToString(" ").trim()
        if (txt.isNotEmpty()) setExpanded(true, txt)
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        Prefs.sp(this).unregisterOnSharedPreferenceChangeListener(this)
        if (added) { try { wm.removeView(island) } catch (_: Exception) {}; added = false }
        super.onDestroy()
    }
}
